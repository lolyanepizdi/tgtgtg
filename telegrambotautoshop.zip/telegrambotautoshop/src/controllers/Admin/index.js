const Scene = require('telegraf/scenes/base')
const Stage = require('telegraf/stage')
const { getAdminKeyBoard } = require('./../../utils/keyboard')
const { leave } = Stage
const { getProducts, createProduct, updateProduct, deleteUser } = require('../../utils/DBHelperProduct');
const cartScene = require('../Cart');

let adding = false;
let isListAddedOrModified = false;
let title = '';
let list = [];
let price = '';
let amount = '';
let image = '';
let products = [];
let changingProperty = ''
let changingProduct = {};
const adminScene = new Scene('adminScene')
adminScene.enter(async (ctx) => {
    products = await getProducts();
    ctx.reply('Панель Администратора', {
        reply_markup: {
            inline_keyboard: getAdminKeyBoard()
        }
    })
});

const showProduct = (ctx, number) => {
    ctx.deleteMessage();
    changingProduct = products[number];
    const getPoints = (array) => {
        let result = '';
        array.map((item) => {
            result += `⭐ ${item}\n`;
        })
        return result
    }
    ctx.replyWithHTML(`${changingProduct.title}\n` +
        (changingProduct.list.length > 0 ? `\n${getPoints(changingProduct.list)}` : '') +
        `\n` +
        `Доступно: ${changingProduct.amount} единиц\n` +
        `\n` +
        `<a href="${changingProduct.image}">${changingProduct.price}</a> грн\n`, {
        reply_markup: {
            inline_keyboard: [
                [{ text: 'Изменить Название', callback_data: 'CHANGE_PRODUCT_TITLE' }],
                [{ text: 'Изменить Список', callback_data: 'CHANGE_PRODUCT_LIST' }],
                [{ text: 'Изменить Цену', callback_data: 'CHANGE_PRODUCT_PRICE' }],
                [{ text: 'Изменить Количество', callback_data: 'CHANGE_PRODUCT_AMOUNT' }],
                [{ text: 'Изменить Изображение', callback_data: 'CHANGE_PRODUCT_IMAGE' }],
                [{ text: 'Удалить продукт', callback_data: 'DELETE_PRODUCT' }],
                [{ text: 'Назад к списку', callback_data: 'PRODUCTS_LIST' }]
            ]
        }
    });
}

const showProductsList = async (ctx) => {
    let keyboard = [];
    products = await getProducts();
    console.log('123', products)
    for (let i = 0; i < products.length; i++) {
        adminScene.action(`EDIT_PRODUCT_${i}`, (ctx) => {
            showProduct(ctx, i);
        })
        keyboard.push([{ text: `${i + 1}. ${products[i].title}`, callback_data: `EDIT_PRODUCT_${i}` }])
    }
    keyboard.push([{ text: 'Создать товар', callback_data: 'CREATE_PRODUCT' }]);
    ctx.reply(
        'Панель Управления товарами\n' +
        '\n' +
        'Перейдите на страницу товара чтобы изменить информацию/количество/удалить товар\n' +
        'Используйте кнопку ниже чтобы создать товар\n'
        , {
            reply_markup: {
                inline_keyboard: keyboard
            }
        })
}

adminScene.action('PRODUCTS_LIST', (ctx) => {
    showProductsList(ctx);
})
adminScene.action('CREATE_PRODUCT', (ctx) => {
    ctx.reply('Введите название:');
    adding = true;
})
adminScene.action('DELETE_PRODUCT', (ctx) => {
    ctx.reply('Удалено!');
    deleteUser(changingProduct._id);
    showProductsList(ctx);
})
adminScene.action('CHANGE_PRODUCT_TITLE', (ctx) => {
    ctx.reply('Введите новое название:');
    changingProperty = 'title';
})
adminScene.action('CHANGE_PRODUCT_LIST', (ctx) => {
    ctx.reply('Вводите новый по одному элементу в сообщении, и затем введите /endlist:');
    changingProperty = 'list';
    changingProduct.list.length = 0;
})
adminScene.action('CHANGE_PRODUCT_PRICE', (ctx) => {
    ctx.reply('Введите новую цену:');
    changingProperty = 'price';
})
adminScene.action('CHANGE_PRODUCT_AMOUNT', (ctx) => {
    ctx.reply('Введите новое количество:');
    changingProperty = 'amount';
})
adminScene.action('CHANGE_PRODUCT_IMAGE', (ctx) => {
    ctx.reply('Введите новую ссылку на изображение:');
    changingProperty = 'image';
})
adminScene.hears(/В Магазин/, (ctx) => ctx.scene.enter('shopScene'))
adminScene.hears(/Главное меню/, (ctx) => ctx.scene.enter('homeScene'))

const saveProperty = (ctx) => {
    updateProduct(changingProduct._id, changingProduct);
    ctx.reply('Изменено!');
    changingProperty = '';
    showProductsList(ctx);
}

adminScene.command('endlist', (ctx) => {
    if (list.length > 0 || (changingProduct && changingProduct.list && changingProduct.list.length > 0)) {
        isListAddedOrModified = true;
        if (list.length > 0)
            ctx.reply('Введите цену:')
        else if (changingProduct && changingProduct.list.length > 0) {
            saveProperty(ctx);
        }
    }
    else {
        ctx.reply('Введите хотя бы 1 пункт:')
    }
})

adminScene.on('message', async (ctx) => {
    if (!ctx.message.text.match(/^[0-9a-zA-Z]+$/)) {
        ctx.reply('Используйте корректные символы при вводе')
    }
    else if (adding) {
        if (!title) {
            title = ctx.message.text;
            ctx.reply('Вводите построчно список и в конце введите /endlist')
        }
        else if (!isListAddedOrModified) {
            list.push(ctx.message.text)
        }
        else if (!price) {
            price = ctx.message.text;
            ctx.reply('Введите доступное количество:')
        }
        else if (!amount) {
            amount = ctx.message.text;
            ctx.reply('Введите ссылку на изображение:')
        }
        else if (!image) {
            image = ctx.message.text;
            let wait = await createProduct({
                title,
                list,
                price,
                amount,
                image
            });
            adding = false;
            ctx.reply('Товар создан!')
            showProductsList(ctx);
        }
    }
    else if (changingProperty && (changingProperty !== 'list' || isListAddedOrModified)) {
        changingProduct[changingProperty] = ctx.message.text;
        saveProperty(ctx);
    }
    else if (changingProperty === 'list') {
        changingProduct.list.push(ctx.message.text);
    }
})



adminScene.hears(/hi/gi, leave())

module.exports = adminScene;
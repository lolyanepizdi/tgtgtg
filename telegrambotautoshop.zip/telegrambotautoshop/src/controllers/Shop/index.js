const Scene = require('telegraf/scenes/base')
const Stage = require('telegraf/stage')
const session = require('telegraf/session')
const { getHomeKeyBoard, getMainBotKeyBoard } = require('./../../utils/keyboard')
const { leave } = Stage
const { getProducts, createProduct, updateProduct, deleteUser } = require('../../utils/DBHelperProduct');

let products = [];
let goods = {};
let page = 0;
let productsForPage = 10;
let productAmount = 1;
let numberS = -1;

const menuIteration = (ctx) => {
    let temparray, chunk = 10;
    let keyboard = []
    productAmount = 1;
    temparray = goods.goods.slice(page + (page * productsForPage), page + (page * productsForPage) + chunk);
    for (let k = 0; k < temparray.length; k++) {
        keyboard.push([{ text: `${temparray[k].title}`, callback_data: `PRODUCT${k}` }]);
    }
    const buttonsKeyBoard = [];
    if (page !== 0) {
        buttonsKeyBoard.push({ text: '⬅️', callback_data: 'BACK_LIST' });
    }
    buttonsKeyBoard.push({ text: `${page + 1}`, callback_data: `NONE` });
    if (page + ((page + 1) * productsForPage) < goods.goods.length) {
        buttonsKeyBoard.push({ text: '➡️', callback_data: 'FORWARD_LIST' });
    }
    if (buttonsKeyBoard)
        keyboard.push(buttonsKeyBoard);
    ctx.reply('Магазин', {
        reply_markup: {
            inline_keyboard: keyboard
        }
    }
    )
}

const shopScene = new Scene('shopScene')

shopScene.enter(async (ctx) => {
        goods.goods = await getProducts();
        page = 0;
        menuIteration(ctx);
});

const showProductAction = (ctx, number) => {
    ctx.deleteMessage();
    numberS = number;
    let temparray, chunk = 10;
    temparray = goods.goods.slice(page + (page * productsForPage), page + (page * productsForPage) + chunk);
    const getPoints = (array) => {
        let result = '';
        array.map((item) => {
            result += `⭐ ${item}\n`;
        })
        return result
    }
    ctx.replyWithHTML(`${temparray[number].title}\n` +
        (temparray[number].list.length > 0 ? `\n${getPoints(temparray[number].list)}` : '') +
        `\n` +
        `<a href="${temparray[number].image}">${temparray[number].price}</a> грн\n`, {
        reply_markup: {
            inline_keyboard: [
                [{ text: '-', callback_data: 'MINUS' }, { text: `${productAmount}`, callback_data: `NONE` }, { text: '+', callback_data: 'PLUS' }],
                [{ text: 'Добавить в корзину', callback_data: 'ADD_TO_CART' }],
                [{ text: 'Назад', callback_data: 'BACK' }]
            ]
        }
    });
}

shopScene.action('MINUS', (ctx) => {
    if (productAmount > 1) {
        productAmount--;
    }
    showProductAction(ctx, numberS);
})
shopScene.action('PLUS', (ctx) => {
    let temparray, chunk = 10;
    temparray = goods.goods.slice(page + (page * productsForPage), page + (page * productsForPage) + chunk);
    if (productAmount < temparray[numberS].amount) {
        productAmount++;
    }
    showProductAction(ctx, numberS);
})
shopScene.action('BACK', (ctx) => {
    ctx.deleteMessage();
    menuIteration(ctx);
})
shopScene.action('BACK_LIST', (ctx) => {
    ctx.deleteMessage();
    page--;
    menuIteration(ctx);
})

shopScene.action('FORWARD_LIST', (ctx) => {
    ctx.deleteMessage();
    page++;
    menuIteration(ctx);
})

shopScene.action('GO_TO_SHOP', (ctx) => {
    ctx.deleteMessage();
    page = 0;
    menuIteration(ctx);
})

shopScene.action('GO_TO_CART', (ctx) => {
    ctx.deleteMessage();
    ctx.scene.enter('cartScene');
})

shopScene.action('ADD_TO_CART', (ctx) => {
    ctx.deleteMessage();
    let temparray, chunk = 10;
    temparray = goods.goods.slice(page + (page * productsForPage), page + (page * productsForPage) + chunk);
    if (ctx.session.cart) {
        ctx.session.cart.push({
            item: temparray[numberS],
            amount: productAmount
        })
    }
    else {
        ctx.session.cart = [{
            item: temparray[numberS],
            amount: productAmount
        }]
    }
    ctx.reply(`Товар ${temparray[numberS].title} добавлен в козину в колличестве ${productAmount} шт`, {
        reply_markup: {
            inline_keyboard: [
                [{ text: 'Корзина', callback_data: 'GO_TO_CART' }],
                [{ text: 'Магазин', callback_data: 'GO_TO_SHOP' }]
            ]
        }
    });
})



for (let i = 0; i < productsForPage; i++) {
    shopScene.action(`PRODUCT${i}`, (ctx) => showProductAction(ctx, i))
}

module.exports = shopScene;
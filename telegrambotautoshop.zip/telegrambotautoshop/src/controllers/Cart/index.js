const Scene = require('telegraf/scenes/base')
const Stage = require('telegraf/stage')
const { getHomeKeyBoard, getMainBotKeyBoard } = require('./../../utils/keyboard')
const { leave } = Stage
const mongoose = require('mongoose');
const Order = require('../../models/order');

let cartProducts = []

const cartScene = new Scene('cartScene')

const forceRerender = (ctx) => {
    ctx.deleteMessage();
    cartSceneIteration(ctx);
}

const calcPayment = (cart) => {
    let payment = 0;
    for (let i = 0; i < cart.length; i++) {
        payment += cart[i].item.price * cart[i].amount;
    }
    return payment;
}

const cartSceneIteration = (ctx) => {
    let cartText = 'Корзина\n';
    let isCartEmpty = !ctx.session.cart || !ctx.session.cart.length;
    cartText += isCartEmpty ? '\nКорзина пуста' : `К оплате: ${calcPayment(ctx.session.cart)} грн\n` +
        'Используйте кнопки ниже чтобы перейти к товару в корзине или удалить товар из корзины'
    let keyboard = [];
    if (isCartEmpty) {
        keyboard.push([{ text: 'Магазин', callback_data: 'GO_TO_SHOP' }])
    }
    else {
        cartProducts = ctx.session.cart;
        for (let i = 0; i < ctx.session.cart.length; i++) {
            cartScene.action(`MINUS_${i}`, (ctx) => {
                if (ctx.session.cart[i].amount > 1) {
                    ctx.session.cart[i].amount--;
                }
                else {
                    ctx.session.cart.splice(i, 1);
                }
                forceRerender(ctx);
            });
            cartScene.action(`PLUS_${i}`, (ctx) => {
                if (ctx.session.cart[i].amount < ctx.session.cart[i].item.amount) {
                    ctx.session.cart[i].amount++;
                }
                forceRerender(ctx);
            });
            cartScene.action(`REMOVE_${i}`, (ctx) => {
                ctx.session.cart.splice(i, 1);
                forceRerender(ctx);
            });
            keyboard.push([{ text: `${i + 1}. ${ctx.session.cart[i].item.title}`, callback_data: `NONE` }])
            keyboard.push([{ text: '-', callback_data: `MINUS_${i}` }, { text: `${ctx.session.cart[i].amount}`, callback_data: `NONE` }, { text: '+', callback_data: `PLUS_${i}` }])
            keyboard.push([{ text: 'Удалить', callback_data: `REMOVE_${i}` }])
        }
        keyboard.push([{ text: 'Перейти к оплате', callback_data: 'BUY' }])
    }
    ctx.reply(cartText, {
        reply_markup: {
            inline_keyboard: keyboard
        }
    });
}
cartScene.enter((ctx) => {
    cartSceneIteration(ctx);

});


cartScene.action('BUY', (ctx) => {
    mongoose.connect('mongodb://localhost:27017/test', {useNewUrlParser: true, useUnifiedTopology: true});
    const order = new Order({
        name: 'THIS IS TEST'
    })
    order.save(function(err){
        mongoose.disconnect();  // отключение от базы данных
          
        if(err) return console.log(err);
        console.log("Сохранен объект", order);
    });
})

cartScene.action('GO_TO_SHOP', (ctx) => {
    ctx.deleteMessage();
    ctx.scene.enter('shopScene')
})

cartScene.hears(/hi/gi, leave())

module.exports = cartScene;
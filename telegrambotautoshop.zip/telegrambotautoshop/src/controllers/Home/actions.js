const Stage = require('telegraf/stage')
const Markup = require('telegraf/markup');
const { leave, enter } = Stage

const toShopAction = (ctx) => {
    ctx.deleteMessage();
    enter('shopScene')
    leave();
}

const toCartAction = (ctx) => {
    ctx.deleteMessage();
    ctx.reply('CART');
}

const toInviteAction = (ctx) => {
    ctx.deleteMessage();
    return ctx.reply('INVITE');
}   


module.exports.toShopAction = toShopAction;
module.exports.toCartAction = toCartAction;
module.exports.toInviteAction = toInviteAction;

const Scene = require('telegraf/scenes/base')
const Stage = require('telegraf/stage')
const { getHomeKeyBoard, getMainBotKeyBoard } = require('./../../utils/keyboard')
const { leave } = Stage
const { toShopAction, toCartAction, toInviteAction } = require('./actions')

const homeScene = new Scene('homeScene')
homeScene.enter((ctx) => {
    ctx.reply('Домашняя страница', {
        reply_markup: {
            inline_keyboard: getHomeKeyBoard()
        }
    })
});

homeScene.action('SHOP', (ctx) => {
    ctx.deleteMessage();
    ctx.scene.enter('shopScene');
})
homeScene.action('CART', (ctx) => {
    ctx.deleteMessage();
    ctx.scene.enter('cartScene');
})
homeScene.action('INVITE', toInviteAction)

homeScene.hears(/hi/gi, leave())

module.exports = homeScene;
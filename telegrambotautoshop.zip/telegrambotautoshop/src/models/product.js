const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const productSchema = new Schema({
    title: String,
    list: [String],
    price: Number,
    amount: Number,
    image: String,
});

const Product = mongoose.model("Product", productSchema);

module.exports = Product;
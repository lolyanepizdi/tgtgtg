const Markup = require('telegraf/markup');

const getMainBotKeyBoard = () => {
    return Markup.keyboard([
        ['🛍️ В Магазин'],
        ['ℹ️ Главное меню', '⬅️ Назад']
    ]).resize().extra()
}

const getHomeKeyBoard = () => { 
    return [
        [{text: '🛍️ В Магазин', callback_data: 'SHOP'}],
        [{text: '🛒 Корзина', callback_data: 'CART'}],
        [{text: '📨 Пригласить Друга', callback_data: 'INVITE'}]
    ]
}

const getAdminKeyBoard = () => { 
    return [
        [{text: '🛍️ Управление товарами', callback_data: 'PRODUCTS_LIST'}],
    ]
}

const getGoodsListKeyboard = () => {
    
}

const getShopKeyBoard = () => {
    return [];
}

module.exports.getHomeKeyBoard = getHomeKeyBoard;
module.exports.getMainBotKeyBoard = getMainBotKeyBoard;
module.exports.getAdminKeyBoard = getAdminKeyBoard;

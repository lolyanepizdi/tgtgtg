require("dotenv").config();
const mongoose = require('mongoose');
const Product = require('../models/product');


const createProduct = (productData) => {
    mongoose.connect(process.env.DB_HOST, { useNewUrlParser: true, useUnifiedTopology: true });
    const product = new Product(productData);
    return new Promise((resolve, reject) => {
        product.save(function (err) {
            if (err) return console.log(err);
            resolve(true)
        });
    })
}

const getProducts = async () => {
    mongoose.connect(process.env.DB_HOST, { useNewUrlParser: true, useUnifiedTopology: true });
    return new Promise((resolve, reject) => {
        Product.find({}, (err, prods) => {
            mongoose.disconnect();
            if (err) return console.log(err);
            resolve(prods);
        })
    })
}

const updateProduct = (id, productData) => {
    mongoose.connect(process.env.DB_HOST, { useNewUrlParser: true, useUnifiedTopology: true });
    Product.updateOne({ _id: id }, productData, function (err) {
        mongoose.disconnect();

        if (err) return console.log(err);
    });
}

const deleteUser = (id) => {
    mongoose.connect(process.env.DB_HOST, { useNewUrlParser: true, useUnifiedTopology: true });
    Product.findByIdAndDelete(id, function (err) {
        mongoose.disconnect();

        if (err) return console.log(err);
    });
}

module.exports.getProducts = getProducts;
module.exports.createProduct = createProduct;
module.exports.updateProduct = updateProduct;
module.exports.deleteUser = deleteUser;


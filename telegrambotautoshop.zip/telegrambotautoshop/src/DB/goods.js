const gooods = {
    "goods": [
        {
            "id": 1,
            "title": "First",
            "list": [
                "123",
                "123",
                "123",
                "123"
            ],
            "price": 1,
            "amount": 10, 
            "image": "https://docs.microsoft.com/ru-ru/windows/uwp/design/controls-and-patterns/images/image_licorice.jpg"
        },
        {
            "id": 2,
            "title": "Second",
            "list": [
                "123",
                "123",
                "123",
                "123"
            ],
            "price": 1,
            "amount": 10, 
            "image": "https://docs.microsoft.com/ru-ru/windows/uwp/design/controls-and-patterns/images/image_licorice.jpg"
        },
        {
            "id": 3,
            "title": "Third",
            "list": [
                "123",
                "123",
                "123",
                "123"
            ],
            "price": 1,
            "amount": 10, 
            "image": "https://docs.microsoft.com/ru-ru/windows/uwp/design/controls-and-patterns/images/image_licorice.jpg"
        }
    ]
}

module.exports = gooods;
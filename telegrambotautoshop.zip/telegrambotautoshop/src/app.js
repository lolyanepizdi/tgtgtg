require("dotenv").config();
const { Telegraf } = require('telegraf')
const session = require('telegraf/session')
const Stage = require('telegraf/stage')
const Scene = require('telegraf/scenes/base')
const homeScene = require('./controllers/Home');
const shopScene = require('./controllers/Shop');
const cartScene = require('./controllers/Cart');
const adminScene = require('./controllers/Admin');
const { getMainBotKeyBoard } = require("./utils/keyboard");
const { leave } = Stage
//

const Bitcoin = require('bitcoin-address-generator');

// Create scene manager
const stage = new Stage()
stage.command('cancel', leave())

// Scene registration
stage.register(homeScene);
stage.register(shopScene);
stage.register(cartScene);
stage.register(adminScene);

const bot = new Telegraf(process.env.BOT_TOKEN)

bot.use(session())
bot.use(stage.middleware())

bot.command('login', (ctx) => ctx.scene.enter('adminScene'))

bot.hears(/В Магазин/, (ctx) => ctx.scene.enter('shopScene'))
bot.hears(/Главное меню/, (ctx) => ctx.scene.enter('homeScene'))

bot.start((ctx) => {
    ctx.reply('Запускаюсь...', getMainBotKeyBoard())
    ctx.scene.enter('homeScene');

    // Bitcoin.createWalletAddress(response => {
    //     console.log(response);
    // });
      
})
bot.launch();